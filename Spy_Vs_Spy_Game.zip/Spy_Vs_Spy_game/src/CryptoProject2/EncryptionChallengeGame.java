package CryptoProject2;

import java.util.Scanner;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class EncryptionChallengeGame {
    private static final int WINNING_SCORE = 5;
    private static final int TIME_LIMIT_SECONDS = 60;
    private static int player1Score = 0;
    private static int player2Score = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Encryption Challenge!");

        while (player1Score < WINNING_SCORE && player2Score < WINNING_SCORE) {
            playRound(scanner, 1);
            if (player1Score >= WINNING_SCORE) break;
            playRound(scanner, 2);
        }

        System.out.println("Game Over!");
        System.out.println(player1Score >= WINNING_SCORE ? "Player 1 Wins!" : "Player 2 Wins!");
        scanner.close();
    }

    private static void playRound(Scanner scanner, int player) {
        System.out.println("\nPlayer " + player + "'s Turn");

        // Ensure input availability for message
        System.out.print("Enter a message to encrypt: ");
        String message = readInput(scanner);
        if (message == null) {
            System.out.println("No valid input received. Skipping turn.");
            return;
        }

        System.out.print("Choose the encryption algorithm (DES or AES): ");
        String algorithm = readInput(scanner);
        if (algorithm == null || !(algorithm.equalsIgnoreCase("DES") || algorithm.equalsIgnoreCase("AES"))) {
            System.out.println("Invalid algorithm choice! Choose either 'DES' or 'AES'.");
            return;
        }

        algorithm = algorithm.toUpperCase();

        System.out.print("Enter the encryption key: ");
        String key = readInput(scanner);
        if (key == null || key.length() < 4) {
            System.out.println("Invalid key! Key must be at least 4 characters long.");
            return;
        }

        try {
            String encryptedMessage = EncryptionChallenge.encrypt(message, key, algorithm);
            System.out.println("Encrypted Message: " + encryptedMessage);

            // Provide a hint to the opponent
            System.out.println("Hint: First 4 characters of the key are: " + key.substring(0, 4));
            System.out.println("you have " + TIME_LIMIT_SECONDS + " seconds to guess the key.");

            AtomicBoolean timeUp = new AtomicBoolean(false);
            Thread countdownThread = new Thread(() -> {
                for (int i = TIME_LIMIT_SECONDS; i > 0; i--) {
                    if (timeUp.get()) break;
                    if (i % 10 == 0&&i!=60) { // Print only every 10 seconds
                        System.out.println("Time remaining: " + i + " seconds");
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                timeUp.set(true);
            });

            ExecutorService executor = Executors.newSingleThreadExecutor();
            Future<String> future = executor.submit(scanner::nextLine);

            countdownThread.start();

            String guessedKey = ""; // Initialize with a default value
            try {
                guessedKey = future.get(TIME_LIMIT_SECONDS, TimeUnit.SECONDS); // Attempt to get user input within the time limit
            } catch (TimeoutException e) {
                System.out.println("Time's up! No input received.");
                timeUp.set(true);
                future.cancel(true);
            } finally {
                timeUp.set(true);
                countdownThread.join();
                executor.shutdownNow();
  
            }

            
            if (!guessedKey.equals(key)) {
                System.out.println("Incorrect key! No points awarded.");
            } else {
                String decryptedMessage = EncryptionChallenge.decrypt(encryptedMessage, guessedKey, algorithm);
                System.out.println("Decrypted Message: " + decryptedMessage);
                if (player == 1) {
                    player1Score++;
                } else {
                    player2Score++;
                }
                System.out.println("Player 1 Score: " + player1Score + " | Player 2 Score: " + player2Score);
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }


    private static String readInput(Scanner scanner) {
        // Check if input is available
        if (scanner.hasNextLine()) {
            return scanner.nextLine().trim();
        }
        return null; // Return null if no input is available
    }
}
