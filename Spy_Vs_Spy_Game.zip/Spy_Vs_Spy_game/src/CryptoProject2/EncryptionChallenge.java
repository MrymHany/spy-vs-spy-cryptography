package CryptoProject2;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
public class EncryptionChallenge {
	// Encrypt the message using the specified algorithm (DES or AES)
    public static String encrypt(String message, String key, String algorithm) throws Exception {
        Cipher cipher;
        SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), algorithm);
        
        if (algorithm.equals("DES")) {
            cipher = Cipher.getInstance("DES");
        } else if (algorithm.equals("AES")) {
            cipher = Cipher.getInstance("AES");
        } else {
            throw new IllegalArgumentException("Invalid algorithm: " + algorithm);
        }

        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(message.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    // Decrypt the message using the specified algorithm (DES or AES)
    public static String decrypt(String encryptedMessage, String key, String algorithm) throws Exception {
        Cipher cipher;
        SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), algorithm);
        
        if (algorithm.equals("DES")) {
            cipher = Cipher.getInstance("DES");
        } else if (algorithm.equals("AES")) {
            cipher = Cipher.getInstance("AES");
        } else {
            throw new IllegalArgumentException("Invalid algorithm: " + algorithm);
        }

        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] encryptedBytes = Base64.getDecoder().decode(encryptedMessage);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        return new String(decryptedBytes);
    }
}

